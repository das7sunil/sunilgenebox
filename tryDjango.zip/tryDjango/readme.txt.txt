urls: 
for passing name through url:= domain_name/sayhi/your_name
for detail book view = domain_name/detail_view	
for creating book = domain_name/create_book
