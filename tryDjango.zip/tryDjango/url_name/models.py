from django.db import models


# Create your models here.

class Book(models.Model):

    author                  = models.ForeignKey("auth.User", on_delete=models.CASCADE)
    title                   = models.CharField(max_length=200)
    date_published			= models.DateTimeField(auto_now_add=True, verbose_name='date published')
    date_updated			= models.DateTimeField(auto_now=True, verbose_name='date updated')


    def __str__(self):
        return self.title
