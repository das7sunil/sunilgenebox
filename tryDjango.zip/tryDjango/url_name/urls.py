from django.urls import path
from . import views
urlpatterns = [
    path('',views.home, name='home'),
    path('sayhi/<username>/',views.Profile, name='profile'),
    path('create_book/',views.create_book_view, name='create_book'),
    path('detail_view/',views.detailed_book_view, name='detail_view'),

]
