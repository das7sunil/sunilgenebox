from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse
from .forms import CreateBook
# Create your views here.

from .models import Book

def home(request):
    return HttpResponse("<h1>enter url 'domain_name/sayhi/your_name'</h1><p>url for book/author:- /detail_view/</p><p>url for create book:- /create_book/</p>")

def Profile(request, username):
    print(username)
    context = {
        'username':username,
        }

    return render(request, 'url_name/user_name.html', context)

def create_book_view(request):
    form = CreateBook(request.POST or None)
    if form.is_valid():
        form.save()

    context = {
        'form':form,
    }
    return render(request, 'url_name/create_book.html', context)

def detailed_book_view(request):

    books = Book.objects.all()
    context = {
        'books':books
    }
    return render(request, 'url_name/detail_view.html', context)
    