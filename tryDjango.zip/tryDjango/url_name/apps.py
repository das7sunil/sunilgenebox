from django.apps import AppConfig


class UrlNameConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'url_name'
