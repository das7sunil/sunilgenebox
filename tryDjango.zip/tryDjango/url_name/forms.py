from django import forms 

from url_name.models import Book 

class CreateBook(forms.ModelForm):

	class Meta:
		model = Book
		fields = ['title','author']